<?php

/**
 * GeneratePress Child Theme
 *
 */




// Child Theme style.css

function example_enqueue_styles() {
	wp_enqueue_style('parent-theme', get_template_directory_uri() .'/style.css');
}
add_action('wp_enqueue_scripts', 'example_enqueue_styles');



// Changing the Copyright Message docs.generatepress.com/article/changing-the-copyright-message/
// or changing the Copyright Message in generatepress-child\inc\structure\footer.php

add_filter( 'generate_copyright','tu_custom_copyright' );
function tu_custom_copyright() {
    ?>
   	<div>
		&copy; <?php echo date("Y"); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>
	</div>	
    <?php
}