<div class="credits">

	<p>
	
		&copy; <?php echo date("Y") ?> <a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>.
<!-- -->
		<?php _e('Theme by', 'garfunkel'); ?> <a rel="nofollow" target="_blank" href="http://www.andersnoren.se">Anders Nor&eacute;n</a>.
<!-- -->
	
	</p>
		
</div> <!-- /credits -->

<?php wp_footer(); ?>

</body>
</html>